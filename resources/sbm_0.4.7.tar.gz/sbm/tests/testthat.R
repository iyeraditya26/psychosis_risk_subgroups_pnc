library(testthat)
library(sbm)
library(aricode)

test_check("sbm")
