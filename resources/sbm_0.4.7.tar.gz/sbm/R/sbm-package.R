#' @keywords internal
"_PACKAGE"

#' @import purrr dplyr
#' @useDynLib sbm, .registration = TRUE
#' @importFrom Rcpp sourceCpp
NULL
